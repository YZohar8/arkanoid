// 211970389 Yonatan Zohar
package Game.animtion;

import Game.interfaces.Animation;
import Game.objects.PrintMessage;
import biuoop.DrawSurface;
import java.awt.Color;

/**
 * The WinGameAnimation class represents an animation displayed when the game is
 * over and user win the game.
 * It implements the Animation interface.
 */
public class WinGameAnimation implements Animation {
    //define magic number
    private static final int FONT1 = 40;
    // define fields
    private int score;

    /**
     * Constructs a WinGameAnimation object with the specified score.
     *
     * @param score The final score of the game
     */
    public WinGameAnimation(int score) {
        this.score = score;

    }

    @Override
    public void doOneFrame(DrawSurface d) {
        PrintMessage print = new PrintMessage(d.getWidth(), d.getHeight());
        d.setColor(Color.GRAY);
        print.printInMiddleLine(Color.BLACK, d, "you won! the game. your"
                        + " score is: " + this.score, FONT1);

    }

    @Override
    public boolean shouldStop() {
        return false;
    }
}

